$(document).ready(function(){

	var main_base ="http://localhost/";
	console.log("welcome to admin \n document is ready");

  // show hide
  $("#main_content_section").hide();



// Events Listner for UI
  $("#sign_up_a").click(function(){
  	console.log("sign_up_a is clicked");
  });
	
$("#sign_in_button").click(function(){
  // get user mc and password
  // send request
  var mc = $("#login_mc_input").val();
  var password = $("#login_password_input").val();
  // validation
  if( mc == null || mc == "" || password == null || password == ""){
    alert("fill mc and password ","Attention");
    return;
  }
  //myApp.showPreloader('Loging in..');
  // login request
  // prepare data
  localStorage.setItem("user_mc",mc);
  localStorage.setItem("user_password",password);
  var post_data = {"ops_type":"login","data":{"mc":mc,"password":password},"user":{"mc":mc,"password":password}};
  var data_str = JSON.stringify(post_data);
  var end_point = main_base+"intakebook_std/api/v1/soldier/index.php";
  //webservice_request(end_point,data_str,"login");
  // hide login form and show main 
  $("#login_section").hide();
  $("#main_content_section").show();
  $("#name_list_section").show().siblings().hide();
}); // sign in button end


  $("#my_course_list_input").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#my_course_list_ul li").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });


  $("#search_name_card_list_input").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    console.log("search_name_card_list_input is "+value);
    $(".name_list_card").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });


  $("#search_course_record_card_list_input").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    console.log("course_record_card_list is "+value);
    $(".course_record_card_list").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });

  $("a.nav-link").on('click',function(){
    var value = $(this).attr("href");
    //value = value.substr(1)
    console.log("li.nav-link is clicked on "+value);
    $("#name_list_section").hide().siblings().hide();
    //if(value == "#")
    $(value).show();

    if(value == "#logout_section"){
      $("#login_section").show();
      $("#main_content_section").hide();
    }

  });

});